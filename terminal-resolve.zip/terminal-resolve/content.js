(function () {
    function updateText() {
        const element = document.querySelector('.rpo4wf-J3yWx.Pce5Kb.dR850e');
        if (element && element.textContent === 'Classroom') {
            element.textContent = '教室';
        }
    }

    // Add the background image and theme styles
    const style = document.createElement('style');
    style.textContent = `
        body {
          background-image: url('https://dynamic-media-cdn.tripadvisor.com/media/photo-o/26/97/39/7f/caption.jpg?w=1200&h=-1&s=1&cx=1920&cy=1080&chk=v1_f31158e4bb953d28a308') !important;
          background-size: cover !important;
          background-position: center !important;
          background-attachment: fixed !important;
        }
        
        div.OX4Vcb {
          background-color: rgba(130, 129, 128, 0.9) !important;
          backdrop-filter: blur(10px) !important;
        }
        
        div.OX4Vcb * {
          color: black !important;
        }

        div.XIpEib.QRiHXd {
          background-image: url('https://cjr.iar.ubc.ca/files/2018/10/The-Social-and-Political-Lives-of-Japanese-Cherry-Blossoms-Banner.jpg') !important;
          background-size: cover !important;
          background-position: center !important;
        }
    `;
    document.head.appendChild(style);

    // Initial update
    updateText();

    // Create observer to handle dynamic content updates
    const observer = new MutationObserver(() => {
        updateText();
    });

    // Start observing document for changes
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
})();

