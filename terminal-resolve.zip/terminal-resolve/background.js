chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "applyTheme") {
        chrome.tabs.query({ url: "https://classroom.google.com/*" }, (tabs) => {
            if (tabs.length === 0) {
                sendResponse({ message: "Classroom not open!" });
                return;
            }

            for (let tab of tabs) {
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ["content.js"]
                });
            }

            sendResponse({ message: "Theme applied!" });
        });

        return true; // Required to use sendResponse asynchronously
    }
});

