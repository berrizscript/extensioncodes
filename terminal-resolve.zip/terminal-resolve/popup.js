document.addEventListener("DOMContentLoaded", function () {
    const input = document.getElementById("command-input");
    const output = document.getElementById("output");

    input.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            event.preventDefault();
            const commandText = input.value.trim();
            if (commandText) {
                executeCommand(commandText);
                input.value = "";
            }
        }
    });

    function executeCommand(command) {
        if (command === "theme1class") {
            applyTheme();
        } else {
            const response = getCommandResponse(command);
            const commandLine = `<p><span class="prompt">user@macbook ~ %</span> ${command}</p>`;
            const outputLine = `<p>${response}</p>`;
            output.innerHTML += commandLine + outputLine;
            output.scrollTop = output.scrollHeight;
        }
    }

    function applyTheme() {
        chrome.runtime.sendMessage({ action: "applyTheme" }, (response) => {
            const outputLine = `<p>${response.message}</p>`;
            output.innerHTML += outputLine;
            output.scrollTop = output.scrollHeight;
        });
    }

    function getCommandResponse(command) {
        switch (command) {
            case "hello":
                return "Hello, world!";
            case "date":
                return new Date().toString();
            case "clear":
                output.innerHTML = "";
                return "";
            default:
                return `zsh: command not found: ${command}`;
        }
    }
});

